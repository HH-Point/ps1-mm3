12c508a (not 12c508)
internal osc, all others off ! (except code protect if you want it)

Throw away the boot disk this is the REAL PSone (PAL) "Onechip" hex so please enjoy it, 
respects go as ever to Gazza who ripped it from the chip. 

All diagrams uploaded in the zip and happy chipping.

This code is based on REI code and as such should be in the public domain as they intended.

