12c508a 
internal RC osc ON, MCLRE/GP3 ON, all others off

Found it in the attic and dumped with Willem.
Really dont know if it works, coz cant find wifing diagram.
Any help appreciated.




