Set to a 12C508 chip and leave all other settings as default.

Can be wired as a 4-Wire clasic on most models by using only pins 1, 5, 6 & 8.

12C508, 12C508A, 12C509, 12C509A