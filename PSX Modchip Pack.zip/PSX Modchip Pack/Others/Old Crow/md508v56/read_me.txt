

Use on all PSX machines, this software includes dual
switch and variable timing modes.


P1.056  on 08-OCT-98    

Due to new psx board mixing signals, this code only outputs
data for a fixed amount of time (20*block of code).
To play a legitimate gold-disk backup of you orginal disk
make sure that you reset the machine with the power switch.
This will send the data header that the PSX wants (and is
missing from your backup.

To play an original disk, power up the PSX, wait approx 30Secs
then press the RESET button, this will not power down the chip
and will allow the original country code info to get to the 
PSX. HOWEVER, this does mean that you will not be able to play
out of country cd's i.e. european disks on a japan machine :o(
To over come this problem, simply make a backup of your out 
of country disk.

Please remeber this is an interim fix.

Because of my limited time available to write this free-ware,
I can't spare the time to go any further with this project 
unless I have the anti-piracy source code. The anti-piracy
code will give me a good head start to progress further

If you want a chip to play all disks, then please post
the anti-piracy source file to me ................

maxking@maxking.com

and i will forward it onto the author.

				enjoy!


				                      PIC-NUTTER

