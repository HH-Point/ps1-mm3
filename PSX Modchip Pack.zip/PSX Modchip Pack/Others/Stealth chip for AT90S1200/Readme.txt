http://hans.liss.pp.se/modchip.html

PlayStation modchip
Introduction

My first MCU project started after I had decided to buy a Sony Playstation. The only games for this system that seemed good enough to buy were Spyro the Dragon and a console RPG that popped up here and there in discussions, with consistently glowing reviews, called Xenogears. The problem was that Xenogears hadn't been released over here and so required a "modchip" to work in a PAL console.
First iteration

I didn't feel inclined to go out and buy a ready-made modchip, much less send my PSX in for fitting one, so instead I went looking for more info on the net.

Sure enough, the modchips available commercially appeared all to be based on the same chip (the Microchip PIC 12C508) and for the most part the same code, by Scott Rider, and this code was available in source form on the net.

Looking through the code with a 12x508 datasheet available, it wasn't hard to reverse-engineer the algorithm and so I started to recode it for the AT90S1200.I built it as a small package with a DIL processor and a Murata ceramic resonator for the clock and I used the same PCB mount points as the 12C508 used - three connections plus a link wire between two points on the PCB. After several attempts and bug fixes, Xenogears booted and then we spent the next 1� months just playing the game..

I later added two more connections, for the reset signal and the lid switch.
Stealth

When Square's Final Fantasy VIII came out in Japan, there were a lot of discussions going on about its "modchip lockout" feature. Speculating that the newer games simply detected the signal from the modchip (which the chips of the day happily kept sending forever) even when there should be no such signal, I modified my code to stop sending after a set number of cycles and brought my PSX to a store where they had the new game (and couldn't run it). It worked, so I felt I had to buy FFVIII shortly thereafter. Not a great game, unfortunately.. [up-to-date note: I have to concede that I have now spent more time playing FFVIII than most other games I have in my possession, so apparently I do like it after all...]
Physical attributes

Later I redesigned the construction on a (roughly) 2x2.5cm PCB, like the picture shows; an SMT design with a LED and a button for setting parameters, and two MicroMaTch connectors for programming and for connection in the console making it easy to remove the modchip PCB for reprogramming.
Final words

I made this chip mainly for myself and haven't seriously considered serial production. My biggest gripe on this subject, apart from the fact that the console companies even bother to try to lock out import games, when not all games are even released in all regions (Xenogears, for example), is that these chips can be used to play CDR copies. I do not want to be involved in software piracy, but I've decided to "publish" the source code here anyway. No HEX files, though. You'll have to do some work yourself to get this running!

Two different versions of the source are attached. 