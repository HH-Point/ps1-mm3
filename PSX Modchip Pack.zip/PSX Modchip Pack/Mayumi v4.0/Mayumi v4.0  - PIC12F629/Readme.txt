Mayumi v4 converted for PICs 12F683, 12F675 & 12F629

Full stealth support (on supported models).

Compatibility:
12F675 Hex: 12F629, 12F675
12F683 Hex: 12F683

Limited testing has been done before release, use at your own risk.

October 20, 2014

--------------------------------------------------------------------------------

From the original Readme:

Mode change press Reset to 2sec

Installed on PU-18,20(Supports 4Modes)
Mayumi Ver0.9 Mode --> Mayumi Ver1.0 Mode --> OLD MOD-Chip mode --> Disable Mode

Installed on PU-22,23(Supports 3Modes)
PU-22,23 Strongest Mode --> OLD MOD-Chip mode --> Disable Mode

WDT_OFF, ExtRC_OSC, MCLR_OFF