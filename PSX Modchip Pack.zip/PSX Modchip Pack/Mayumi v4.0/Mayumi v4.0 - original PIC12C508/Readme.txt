Mode change press Reset to 2sec

Installed on PU-18,20(Supports 4Modes)
Mayumi Ver0.9 Mode --> Mayumi Ver1.0 Mode --> OLD MOD-Chip mode --> Disable Mode

Installed on PU-22,23(Supports 3Modes)
PU-22,23 Strongest Mode --> OLD MOD-Chip mode --> Disable Mode

WDT_OFF, ExtRC_OSC, MCLR_OFF


Chips: 12C508, 12C508A, 12C509, 12C509A (also worked with 12F508 when tested)

Code Protect is ON by default.
This will cause the chip to not be verified properly and should be disabled.